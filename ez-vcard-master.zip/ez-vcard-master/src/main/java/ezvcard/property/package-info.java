/**
 * Contains the DTO class for each property. 
 */
package ezvcard.property;