/**
 * Contains classes that can read/write jCards (JSON-encoded vCards).
 */
package ezvcard.io.json;