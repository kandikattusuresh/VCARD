/**
 * Contains classes that can read/write xCards (XML-encoded vCards).
 */
package ezvcard.io.xml;