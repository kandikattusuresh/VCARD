/**
 * Contains classes used in the chaining API.
 * @see ezvcard.Ezvcard
 */
package ezvcard.io.chain;